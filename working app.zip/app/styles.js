`use-strict`;
import { StyleSheet } from "react-native-web";
module.exports = StyleSheet.create({
  mainText: {
    fontSize: 20,
    color: "black",
  },
});
