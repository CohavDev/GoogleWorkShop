import { StyleSheet, Text, View, ImageBackground } from "react-native";
import React from "react";
import CategoryCircle from "../components/CategoryCircle";

export default function HomeScreen() {
  return (
    <ImageBackground
      source={require("../assets/Image.jpg")}
      style={styles.image}
    >
      <Text style={styles.text}>Add a New Activity</Text>
      <View style={styles.circlesLayout}>
        <CategoryCircle
          text="Hike"
          imageSource="../assest/mountain_track_small.jpg"
        ></CategoryCircle>
        <CategoryCircle
          text="Bar"
          imageSource="../assest/mountain_track_small.jpg"
        ></CategoryCircle>
        <CategoryCircle
          text="Restaurant"
          imageSource="../assest/mountain_track_small.jpg"
        ></CategoryCircle>
        <CategoryCircle
          text="Place to Sleep"
          imageSource="../assest/mountain_track_small.jpg"
        ></CategoryCircle>
        <CategoryCircle
          text="Party"
          imageSource="../assest/mountain_track_small.jpg"
        ></CategoryCircle>
        <CategoryCircle
          text="Driving"
          imageSource="../assest/mountain_track_small.jpg"
        ></CategoryCircle>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  image: {
    flex: 1,
    justifyContent: "center",
    width: "100%",
    height: "100%",
  },
  text: {
    color: "#535050",
    // backgroundColor: "rgba(228, 133, 196, 0.6)",
    fontSize: 20,
    lineHeight: 50,
    fontWeight: "bold",
    fontFamily: "Roboto",
    textAlign: "center",
  },
  circlesLayout: {
    justifyContent: "space-between",
    flexDirection: "row",
    flexWrap: "wrap",
  },
});
